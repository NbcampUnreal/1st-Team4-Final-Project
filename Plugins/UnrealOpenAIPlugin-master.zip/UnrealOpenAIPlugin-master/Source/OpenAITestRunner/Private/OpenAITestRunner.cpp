// OpenAI, Copyright LifeEXE. All Rights Reserved.

#include "OpenAITestRunner.h"

#define LOCTEXT_NAMESPACE "FOpenAITestRunnerModule"

void FOpenAITestRunnerModule::StartupModule() {}
void FOpenAITestRunnerModule::ShutdownModule() {}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FOpenAITestRunnerModule, OpenAITestRunner)
