// OpenAI, Copyright LifeEXE. All Rights Reserved.

#include "OpenAI.h"

#define LOCTEXT_NAMESPACE "FOpenAIModule"

void FOpenAIModule::StartupModule() {}
void FOpenAIModule::ShutdownModule() {}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FOpenAIModule, OpenAI)
