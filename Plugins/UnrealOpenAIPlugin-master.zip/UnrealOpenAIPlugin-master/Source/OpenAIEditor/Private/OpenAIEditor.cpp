// OpenAI, Copyright LifeEXE. All Rights Reserved.

#include "OpenAIEditor.h"

#define LOCTEXT_NAMESPACE "FOpenAIEditorModule"

void FOpenAIEditorModule::StartupModule() {}
void FOpenAIEditorModule::ShutdownModule() {}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FOpenAIEditorModule, OpenAIEditor)
