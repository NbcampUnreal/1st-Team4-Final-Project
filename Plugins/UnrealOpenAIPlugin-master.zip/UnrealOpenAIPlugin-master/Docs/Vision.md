﻿# Vision

[Vision](https://platform.openai.com/docs/guides/vision) is now available in `Editor ChatGPT`:

![](https://github.com/life-exe/UnrealOpenAIPlugin/blob/master/Media/vision_1.png)

![](https://github.com/life-exe/UnrealOpenAIPlugin/blob/master/Media/vision_2.png)

Notes: 
- Please select `gpt-4-vision-preview` the model.
- You can attach several images. However, for this, you need to open the file dialog again, as multiple file selection is not currently supported.
- Functions (services) are not available with a vision model.
