﻿# DALL·E 3

[DALL·E 3](https://openai.com/dall-e-3) is now available with all parameters:

![](https://github.com/life-exe/UnrealOpenAIPlugin/blob/master/Media/dalle3_1.png)

Preview mode has been added:

![](https://github.com/life-exe/UnrealOpenAIPlugin/blob/master/Media/dalle3_2.png)

Notes: 
- You can only generate one image with `Dalle3` per request.
- Image variation and image edit requests are only supported by `Dalle2`.
