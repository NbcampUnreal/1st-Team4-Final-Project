﻿#pragma once

#include "CoreMinimal.h"
#include "Engine/CancellableAsyncAction.h"
#include "RequestOllamaChatAction.generated.h"

UCLASS()
class OLLAMAPROVIDER_API URequestOllamaChatAction : public UCancellableAsyncAction
{
	GENERATED_BODY()
};

