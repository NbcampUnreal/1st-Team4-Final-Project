// Copyright Prajwal Shetty 2024. All rights Reserved. https://prajwalshetty.com/terms

#include "Data/OpenAI/GenOAIChatStructs.h"
#include "Data/OpenAI/GenOAIModels.h"

// Implementation of any struct methods if needed
