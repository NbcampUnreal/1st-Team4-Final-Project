// Fill out your copyright notice in the Description page of Project Settings.


#include "Utilities/GenGlobalDefinitions.h"

DEFINE_LOG_CATEGORY(LogGenAI)
DEFINE_LOG_CATEGORY(LogGenPerformance)
DEFINE_LOG_CATEGORY(LogGenAIVerbose)