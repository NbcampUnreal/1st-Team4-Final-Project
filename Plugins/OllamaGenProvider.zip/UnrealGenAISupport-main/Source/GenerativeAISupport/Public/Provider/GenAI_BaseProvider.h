﻿#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "GenAI_BaseProvider.generated.h"

UCLASS(Abstract, Blueprintable)
class OLLAMAGENPROVIDER_API UGenAI_BaseProvider : public UObject    
{
    GENERATED_BODY()   
};